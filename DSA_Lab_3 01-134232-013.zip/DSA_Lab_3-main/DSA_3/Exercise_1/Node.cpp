#include "Node.h"

Node::Node(int val) {
    value = val;
    next = NULL;
}
