

#include "Node.h"

class LinkedList {
private:
    Node* head;

public:
    LinkedList();
    void insert(int val);
    void display();
    ~LinkedList();
};

