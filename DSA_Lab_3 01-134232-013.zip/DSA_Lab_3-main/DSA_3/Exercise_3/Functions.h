

#include "LinkedList.h"

void concatenate(LinkedList& list1, LinkedList& list2);
LinkedList intersection(LinkedList& list1, LinkedList& list2);
int compare(LinkedList& list1, LinkedList& list2);

