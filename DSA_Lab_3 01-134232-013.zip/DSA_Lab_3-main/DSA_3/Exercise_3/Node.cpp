#include "Node.h"

Node::Node(char val) {
    value = val;
    next = NULL;
}
