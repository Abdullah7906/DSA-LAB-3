#include <iostream>
using namespace std;

class Node {
public:
    char value;
    Node* next;

    Node(char val);
};

